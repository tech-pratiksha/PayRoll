﻿using Microsoft.AspNetCore.Mvc;
using PayRollManagementSystemAPI.Contracts;
using PayRollManagementSystemAPI.ViewModels;
using Newtonsoft.Json;
using PayRollManagementSystemAPI.Models;
using PayRollManagementSystemAPI.NewFolder;
using Microsoft.AspNetCore.Cors;
using PayRollManagementSystemAPI.Repositories;

namespace PayRollManagementSystemAPI.Controllers
{
    [Route("EmployeeController/")]

    public class EmployeeController : Controller
    {
        private readonly ILeaveRepository _leaveRepository;
        private readonly IUserRepository _userRepository;
        public EmployeeController(ILeaveRepository leaveRepository, IUserRepository userRepository)
        {
            _leaveRepository = leaveRepository;
            _userRepository = userRepository;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return Json("Working");
        }

        #region ApplyLeave
        /// <summary>
        /// Used for applying leave
        /// </summary>
        /// <param name="leaveViewModel"></param>
        /// <returns>message</returns>
        [HttpPost]
        [Route("ApplyLeave")]
        public async Task<IActionResult> ApplyLeave([FromBody] LeaveViewModel leaveViewModel)
        {
            try
            {
                // Validate the input model
                if (leaveViewModel == null)
                {
                    return BadRequest(new { message = "LeaveViewModel cannot be null." });
                }

                if (string.IsNullOrEmpty(leaveViewModel.UserId))
                {
                    return BadRequest(new { message = "UserId is required." });
                }

                if (leaveViewModel.LeaveStartDate == default || leaveViewModel.LeaveEndDate == default)
                {
                    return BadRequest(new { message = "LeaveStartDate and LeaveEndDate are required." });
                }

                if (leaveViewModel.LeaveEndDate < leaveViewModel.LeaveStartDate)
                {
                    return BadRequest(new { message = "LeaveEndDate cannot be earlier than LeaveStartDate." });
                }

                // Process the leave request
                var result = await _leaveRepository.Create(leaveViewModel.UserId, leaveViewModel);

                if (result == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, new { message = "Failed to create leave request." });
                }

                //return Ok(new { message = "Leave request created successfully.", data = result });
                return Ok(result);
            }
            catch (ArgumentNullException ex)
            {
                // Handle specific exception
                return BadRequest(new { message = "Missing required data.", details = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { message = "Invalid argument.", details = ex.Message });
            }
            catch (FormatException ex)
            {
                return BadRequest(new { message = "Invalid data format.", details = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = "Operation failed.", details = ex.Message });
            }
            catch (Exception ex)
            {
                // Generic exception handler for unexpected errors
                return StatusCode(StatusCodes.Status500InternalServerError, new { message = "An unexpected error occurred.", details = ex.Message });
            }
        }
        #endregion
        //code before change
        ////public async Task<IActionResult> AppplyLeave([FromBody] LeaveViewModel leaveViewModel)
        ////{
        ////    if (leaveViewModel != null)
        ////    {
        ////        return Json(await _leaveRepository.Create(leaveViewModel.UserId, leaveViewModel));
        ////    }
        ////    return null;
        ////}
        [HttpGet]
        [Route("GetAllLeavesById/{id}")]
        public async Task<IActionResult> LeaveReport(string id)
        {
            if (id != null)
            {
                return Json(await _leaveRepository.GetAllLeavesById(id));
            }
            return null;
        }
        [HttpGet]
             [Route("GetAllLeavesByMonthById")]
             public async Task<IActionResult> LeaveReportByMonth(string id, DateTime date)
             {
                 if (id != null)
                 {
                     return Json(await _leaveRepository.GetAllLeavesByMonthById(id, date));
                 }
                 return null;
             }
             [HttpGet]
             [Route("GetAllLeavesByYearById")]
             public async Task<IActionResult> LeaveReportByYear(string id, DateTime startYear, DateTime endYear)
             {
                 if (id != null)
                 {
                     return Json(await _leaveRepository.GetAllLeavesByYearById(id, startYear, endYear));
                 }
                 return null;
             }
             [HttpGet]
             [Route("GetEmployeeById/{id}")]
             public async Task<IActionResult> GetEmployeeById(string id)
             {
                 if (id != null)
                 {
                     AccountUser user = await _userRepository.GetEmployeeById(id);
                     string obj = JsonConvert.SerializeObject(user);
                     UserViewModel userViewModel = JsonConvert.DeserializeObject<UserViewModel>(obj);
                     return Json(userViewModel);
                 }
                 return BadRequest();
             }
        }
    }


