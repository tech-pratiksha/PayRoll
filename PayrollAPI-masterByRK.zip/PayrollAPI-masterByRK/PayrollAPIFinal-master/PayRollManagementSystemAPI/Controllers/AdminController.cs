﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using PayRollManagementSystemAPI.Contracts;
using PayRollManagementSystemAPI.Models;
using PayRollManagementSystemAPI.NewFolder;
using PayRollManagementSystemAPI.ViewModels;

namespace PayRollManagementSystemAPI.Controllers
{
    [EnableCors("CorsPolicy")]
    [Route("AdminController/")]
  
    public class AdminController : Controller
    {
        private readonly IUserRepository _userRepository;
        private readonly IAllowanceRepository _allowanceRepository;
        private readonly ISalaryRepository _salaryRepository;
        private readonly ILeaveRepository _leaveRepository;
        private readonly UserManager<AccountUser> _userManager;
        private readonly IPasswordHasher<AccountUser> _passwordHasher;
        private readonly SignInManager<AccountUser> _signInManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        public AdminController(IUserRepository userRepository,UserManager<AccountUser> userManager,
            IPasswordHasher<AccountUser> passwordHasher,SignInManager<AccountUser> signInManager,
            RoleManager<IdentityRole> roleManager,IAllowanceRepository allowanceRepository,
            ISalaryRepository salaryRepository,ILeaveRepository leaveRepository )
        {
            _userRepository = userRepository;
            _userManager = userManager;
            _passwordHasher = passwordHasher;
            _signInManager = signInManager;
            _roleManager = roleManager;
            _allowanceRepository = allowanceRepository;
            _salaryRepository = salaryRepository;
            _leaveRepository = leaveRepository;
        }
        [HttpGet]
        public IActionResult Index()
        {
            return Json("Working after changes added");
        }
        //Inserting Employee into the database
        [HttpPost]
        [Route("CreateEmployee")]
        public async Task<IActionResult> CreateEmployee([FromBody] EmployeeViewModel employee)
        {
            if (employee == null)
            {
                return BadRequest("Invalid employee data.");
            }
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            string serializedEmployee = JsonConvert.SerializeObject(employee);
            var user = JsonConvert.DeserializeObject<AccountUser>(serializedEmployee);
            user.UserName = employee.Email.Split('@')[0];
            if (employee.UserName!=user.UserName)
            {
                return BadRequest("Your username and the part before '@' in your email address must match.");
            }

            // Ensure the "employee" role exists
            if (!await _roleManager.RoleExistsAsync("employee"))
            {
                var roleResult = await _roleManager.CreateAsync(new IdentityRole("employee"));
                if (!roleResult.Succeeded)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create 'employee' role.");
                }
            }

            // Attempt to create the employee
            var result = await CreateEmployeeFunc(employee);

            if (result is JsonResult jsonResult && jsonResult.Value != null)
            {
                if (result is ObjectResult objectResult && objectResult.StatusCode.HasValue)
                {
                    return result;
                }
                return Ok(jsonResult.Value);
            }

            return BadRequest("An unexpected error occurred while creating the employee.");
        }

        private async Task<IActionResult> CreateEmployeeFunc(EmployeeViewModel employee)
        {
            try
            {
                // Serialize and deserialize the employee object to map to `AccountUser`
                string serializedEmployee = JsonConvert.SerializeObject(employee);
                var user = JsonConvert.DeserializeObject<AccountUser>(serializedEmployee);

                if (user == null)
                {
                    return Json(new { Success = false, Message = "Failed to map employee data to AccountUser." });
                }

                // Populate additional fields
                user.Package = await _allowanceRepository.GetAllowancesById(employee.AllowanceId);
                if (user.Package== null)
                {
                    return Json(new { Success = false, Message = "Failed to map AllowanceClassPackageId to AllowanceID." });
                }
                user.UserName = employee.Email.Split('@')[0];
                user.FullName = $"{employee.FirstName} {employee.LastName}";

                // Create the user in the database
                var creationResult = await _userManager.CreateAsync(user, employee.Password);

                if (creationResult.Succeeded)
                {
                    await _userManager.AddToRoleAsync(user, "employee");

                    // Retrieve the user to return as a response
                    var createdUser = await _userManager.FindByEmailAsync(user.Email);
                    return Json(createdUser);
                }

                // Handle creation errors
                return Json(new { Success = false, Errors = creationResult.Errors });
            }
            catch (Exception ex)
            {
                // Log the exception (assuming a logger is available)
                // _logger.LogError(ex, "Error creating employee");

                return Json(new { Success = false, Message = "An error occurred while creating the employee.", Details = ex.Message });
            }
        }
        ////public async Task<IActionResult> CreateEmployee([FromBody] EmployeeViewModel employee,int id)
        ////{
        ////    if (!await _roleManager.RoleExistsAsync("employee"))
        ////    {
        ////        await _roleManager.CreateAsync(new IdentityRole("employee"));
        ////        return Json(await CreateEmployeeFunc(employee,employee.AllowanceId));
        ////    }
        ////    else
        ////    {
        ////        var result = Json(await CreateEmployeeFunc(employee, employee.AllowanceId));
        ////        if (result.StatusCode != null) 
        ////        { 
        ////            return result;
        ////        }
        ////        return BadRequest(result.Value) ;
        ////    }
        ////}
        //////Inserting Employee Function which will be triggered when CreateEmployee Called
        ////private async Task<IActionResult> CreateEmployeeFunc(EmployeeViewModel employee,int id)
        ////{
        ////    string obj = JsonConvert.SerializeObject(employee);
        ////    AccountUser user = new AccountUser();
        ////    user = JsonConvert.DeserializeObject<AccountUser>(obj);
        ////    user.Package = await _allowanceRepository.GetAllowancesById(id);
        ////    user.UserName = employee.Email.Split('@')[0];
        ////    user.FullName = employee.FirstName +" "+ employee.LastName;
        ////    var result = await _userManager.CreateAsync(user, employee.Password);
        ////    if (result.Succeeded)
        ////    {
        ////        await _userManager.AddToRoleAsync(user, "employee");
        ////        user = await _userManager.FindByEmailAsync(user.Email);
        ////        return Json(user);
        ////    }
        ////    else return Json(result);
        ////}
        //Inserting Admin into the database
        //[HttpPost]
        //[Route("CreateAdmin")]
        //[Consumes("application/json")]
        //public async Task<IActionResult> CreateAdmin( [FromBody] AdminViewModel admin)
        //{

        //    if (!await _roleManager.RoleExistsAsync("admin"))
        //    {
        //        await _roleManager.CreateAsync(new IdentityRole("admin"));
        //        return Json(await CreateAdminFunc(admin));
        //    }
        //    else
        //    {
        //        return Json(await CreateAdminFunc(admin));
        //    }

        //}
        ////Inserting Admin Function which will be triggered when CreateEmployee Called
        //private async Task<IActionResult> CreateAdminFunc( [FromBody] AdminViewModel admin)
        //{
        //    string obj = JsonConvert.SerializeObject(admin);
        //    AccountUser user = new AccountUser();
        //    user = JsonConvert.DeserializeObject<AccountUser>(obj);
        //    user.UserName = admin.Email.Split('@')[0];
        //    var result = await _userManager.CreateAsync(user, admin.Password);
        //    if (result.Succeeded)
        //    {
        //        await _userManager.AddToRoleAsync(user, "admin");
        //        return Json(user);
        //    }
        //    else return null;
        //}

        [HttpPost]
        [Route("CreateAdmin")]
        [Consumes("application/json")]
        public async Task<IActionResult> CreateAdmin([FromBody] AdminViewModel admin)
        {
            if (admin == null)
            {
                return BadRequest("Admin data is null.");
            }

            // Ensure the "admin" role exists
            if (!await _roleManager.RoleExistsAsync("admin"))
            {
                var roleResult = await _roleManager.CreateAsync(new IdentityRole("admin"));
                if (!roleResult.Succeeded)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create 'admin' role.");
                }
            }

            // Delegate admin creation to a helper method
            var result = await CreateAdminFunc(admin);

            // Return the result of the helper method
            return result;
        }

        private async Task<IActionResult> CreateAdminFunc(AdminViewModel admin)
        {
            try
            {
                // Convert AdminViewModel to AccountUser
                var user = new AccountUser
                {
                    Email = admin.Email,
                    UserName = admin.Email.Split('@')[0],
                    FullName = admin.FirstName + " " + admin.LastName,
                    FirstName = admin.FirstName,
                    LastName = admin.LastName,
                    Address = admin.Address,
                    PhoneNumber = admin.PhoneNumber,
                    Position = admin.Position,
                };

                // Create the user in the database
                var creationResult = await _userManager.CreateAsync(user, admin.Password);

                if (creationResult.Succeeded)
                {
                    // Add the "admin" role to the user
                    var roleAssignmentResult = await _userManager.AddToRoleAsync(user, "admin");
                    if (!roleAssignmentResult.Succeeded)
                    {
                        return StatusCode(StatusCodes.Status500InternalServerError, "Failed to assign 'admin' role to user.");
                    }

                    // Return the created user
                    return Ok(user);
                }

                // Handle creation errors
                return BadRequest(new { Success = false, Errors = creationResult.Errors });
            }
            catch (Exception ex)
            {
                // Log the exception (if a logger is available)
                // _logger.LogError(ex, "Error creating admin");

                return StatusCode(StatusCodes.Status500InternalServerError, new
                {
                    Success = false,
                    Message = "An error occurred while creating the admin.",
                    Details = ex.Message
                });
            }
        }
        ////public async Task<IActionResult> CreateAdmin([FromBody] AdminViewModel admin)
        ////{
        ////    if (admin == null)
        ////    {
        ////        return BadRequest("Admin data is null");
        ////    }
        ////    if (!await _roleManager.RoleExistsAsync("admin"))
        ////    {
        ////        await _roleManager.CreateAsync(new IdentityRole("admin"));
        ////    }
        ////    return await CreateAdminFunc(admin);
        ////}
        ////private async Task<IActionResult> CreateAdminFunc(AdminViewModel admin)
        ////{
        ////    string obj = JsonConvert.SerializeObject(admin);
        ////    AccountUser user = JsonConvert.DeserializeObject<AccountUser>(obj);
        ////    user.UserName = admin.Email.Split('@')[0];
        ////    var result = await _userManager.CreateAsync(user, admin.Password);
        ////    if (result.Succeeded)
        ////    {
        ////        await _userManager.AddToRoleAsync(user, "admin");
        ////        return Ok(user);
        ////    }
        ////    else
        ////    {
        ////        return BadRequest("Failed to create admin");
        ////    }
        ////}

        //Add Class method is used to call when admin is creating a new class
        [HttpPost]
        [Route("AddClass")]
        public async Task<IActionResult> AddClass([FromBody] AllowanceViewModel allowanceViewModel)
        {
            if (allowanceViewModel != null)
                return Json(await _allowanceRepository.CreateAllowance(allowanceViewModel));
            else
                return BadRequest();
        }

        // update class Method used when admin to update allowance and deduction
        [HttpPost]
        [Route("UpdateClass")]
        public async Task<IActionResult> UpdateClass([FromBody] AllowanceViewModel allowanceViewModel)
        {
            if (allowanceViewModel != null)
            {
                return Json(await _allowanceRepository.UpdateAllowance(allowanceViewModel));
            }
            return BadRequest();
        }
        [HttpGet]
        [Route("GetAllPendingLeaves")]
        public async Task<IActionResult> GetAllPendingLeaves()
        {
            List<DisplayLeaveModel> leaves = await _leaveRepository.GetAllPendingLeaves();
            return Json(leaves);
        }
        [HttpPost]
        [Route("ApproveLeave/{id}")]
        public async Task<IActionResult> ApproveLeave(int id)
        {
            if(id != null)
            {
                //leave.LeaveStatus = "approved";
                return Json(await _leaveRepository.UpdateLeaveStatus(id));
            }
            return null;
        }
        [HttpPost]
        [Route("RejectLeave/{id}")]
        public async Task<IActionResult> RejectLeave(int id)
        {
            if (id != null)
            {

                return Json(await _leaveRepository.UpdateRejectLeave(id));
            }
            return null;
        }
        [HttpGet]
        [Route("GenerateSalary/{id}")]
        public async Task<IActionResult> GenerateSalary(string id)
        {
            if(id!=null)
            {
                DateTime month = DateTime.Now;
                return Json(await _salaryRepository.GenerateSalary(id,month));
            }
            return BadRequest();
        }
        //Method to retrive all allowance and deductions
        [HttpGet]
        [Route("GetAllAllowances")]
        public async Task<IActionResult> GetAllAllowances()
        {
            List<AllowanceAndDeduction> allowDed = await _allowanceRepository.GetAllAllowances();
            return Json(allowDed);
        }
        [HttpGet]
        [Route("GetAllEmployees")]
        public async Task<IActionResult> GetAllEmployees()
        {
            List<AccountUser> employees = await _userRepository.GetAllEmployees();
            List<UserViewModel> employeeViewModels = new List<UserViewModel>();
            foreach (AccountUser user in employees)
            {
                string obj = JsonConvert.SerializeObject(user);
                UserViewModel userViewModel = JsonConvert.DeserializeObject<UserViewModel>(obj);
                employeeViewModels.Add(userViewModel);
            }
            return Json(employeeViewModels);
        }
        [HttpGet]
        [Route("GetAllAdmins")]
        public async Task<IActionResult> GetAllAdmins()
        {
            List<AccountUser> admins = await _userRepository.GetAllAdmins();
            List<UserViewModel> adminViewModels = new List<UserViewModel>();
            foreach (AccountUser user in admins)
            {
                string obj = JsonConvert.SerializeObject(user);
                UserViewModel userViewModel = JsonConvert.DeserializeObject<UserViewModel>(obj);
                adminViewModels.Add(userViewModel);
            }
            return Json(adminViewModels);
        }
        [HttpGet]
        [Route("GetAdminById/{id}")]
        public async Task<IActionResult> GetAdminById(string id)
        {
            if (id != null)
            {
                AccountUser user = await _userRepository.GetAdminById(id);
                string obj = JsonConvert.SerializeObject(user);
                UserViewModel userViewModel = JsonConvert.DeserializeObject<UserViewModel>(obj);
                return Json(userViewModel);
            }
            return BadRequest();
        }
        [HttpGet]
        [Route("GetAllApprovedLeaves")]
        public async Task<IActionResult> GetAllApprovedLeaves()
        {
            List<DisplayLeaveModel> leaves = await _leaveRepository.GetAllApprovedLeaves();
            return Json(leaves);
        }
        [HttpGet]
        [Route("GetAllRejectedLeaves")]
        public async Task<IActionResult> GetAllRejectedLeaves()
        {
            List<DisplayLeaveModel> leaves = await _leaveRepository.GetAllRejectedLeaves();
            return Json(leaves);
        }
        [HttpPost]
        [Route("UpdateEmployee")]
        public async Task<IActionResult> UpdateEmployee([FromBody]UserViewModel employee)
        {
            if (employee != null) {
                AccountUser user = await _userRepository.GetEmployeeById(employee.Id);
                //AccountUser user = await _userManager.FindByIdAsync(employee.Id);
                if (user != null)
                {
                    user.FirstName = employee.FirstName;
                    user.LastName = employee.LastName;
                    user.Email = employee.Email;
                    user.Address = employee.Address;
                    user.PhoneNumber = employee.PhoneNumber;
                    user.Position = employee.Position;
                    user.JoiningDate = employee.JoiningDate; 
                    user.FullName = user.FirstName+ " "+user.LastName;
                    return Json(await _userRepository.UpdateEmployee(user));
                }
                return BadRequest();
            }
            return BadRequest();
        }
        [HttpPost]
        [Route("UpdateAdmin")]
        public async Task<IActionResult> UpdateAdmin([FromBody] UserViewModel employee)
        {
            if (employee != null)
            {
                AccountUser user = await _userRepository.GetAdminById(employee.Id);
                //AccountUser user = await _userManager.FindByIdAsync(employee.Id);
                if (user != null)
                {
                    user.FirstName = employee.FirstName;
                    user.LastName = employee.LastName;
                    user.Email = employee.Email;
                    user.Address = employee.Address;
                    user.PhoneNumber = employee.PhoneNumber;
                    user.Position = employee.Position;
                    user.JoiningDate = employee.JoiningDate;
                    user.FullName = user.FirstName + " " + user.LastName;
                    return Json(await _userRepository.UpdateAdmin(user));
                }
                return BadRequest("No Admin with this UserName.");
            }
            return BadRequest();
        }
    }
}
